#!/bin/bash
docker run -d -p 8080:80 taboalan/web1-taboada
